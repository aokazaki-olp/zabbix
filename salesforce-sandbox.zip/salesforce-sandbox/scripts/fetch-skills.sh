#!/usr/bin/env bash
# fetch-skills.sh — 公式スキルをピン留めコミットから再取得する。
# 取得するのは許可6スキルのみ。除外スキル(dx-org-switch / connected-app系)は取得しない。
set -euo pipefail

REPO="https://github.com/forcedotcom/sf-skills"
PIN="4bc39ed386445987b3031675c960eb7f3f9cc3d9"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DST="$ROOT/.claude/skills"

# 許可6スキル（現行名）。
ALLOWED=(
  platform-flexipage-generate
  platform-custom-field-generate
  platform-list-view-generate
  platform-validation-rule-generate
  platform-permission-set-generate
  platform-docs-get
)

# 明示的に取得禁止（安全のための二重チェック）。
DENIED=(dx-org-switch integration-connectivity-connected-app-configure switching-org configuring-connected-apps)

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# Node-only 化した platform-docs-get/scripts/fetch-doc.mjs を退避（あれば）。
DOCS_HELPER="$DST/platform-docs-get/scripts/fetch-doc.mjs"
if [[ -f "$DOCS_HELPER" ]]; then cp "$DOCS_HELPER" "$TMP/fetch-doc.mjs.keep"; fi

echo "cloning $REPO @ $PIN ..."
git clone --quiet --depth 1 "$REPO" "$TMP/repo"
git -C "$TMP/repo" fetch --quiet --depth 1 origin "$PIN"
git -C "$TMP/repo" checkout --quiet "$PIN"

for s in "${ALLOWED[@]}"; do
  src="$TMP/repo/skills/$s"
  if [[ ! -d "$src" ]]; then echo "ERROR: skill not found at pin: $s" >&2; exit 1; fi
  rm -rf "${DST:?}/$s"
  cp -r "$src" "$DST/$s"
  echo "  ok: $s"
done

# Node-only 化を再適用: platform-docs-get の python/playwright を撤去し、node ヘルパを戻す。
rm -f "$DST/platform-docs-get/scripts/"*.py "$DST/platform-docs-get/scripts/requirements.txt"
mkdir -p "$DST/platform-docs-get/scripts"
if [[ -f "$TMP/fetch-doc.mjs.keep" ]]; then
  cp "$TMP/fetch-doc.mjs.keep" "$DOCS_HELPER"
  echo "  re-applied Node-only helper: platform-docs-get/scripts/fetch-doc.mjs"
else
  echo "  NOTE: fetch-doc.mjs が見つかりません。SKILLS_PIN.md を参照して再配置してください。" >&2
fi
echo "  NOTE: platform-docs-get の SKILL.md は Node-only 版に手当てが必要です（cliTools/参照index）。SKILLS_PIN.md参照。" >&2

# 二重チェック: 除外スキルが混入していないこと。
for d in "${DENIED[@]}"; do
  if [[ -e "$DST/$d" ]]; then echo "ERROR: denied skill present: $d" >&2; exit 1; fi
done

echo "done. pinned commit: $PIN"
