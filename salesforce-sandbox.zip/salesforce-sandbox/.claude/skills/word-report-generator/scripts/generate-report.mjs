#!/usr/bin/env node
// generate-report.mjs — 承認済みSandbox改修の「本番反映依頼書」(.docx)を生成する。
// 使い方: node scripts/generate-report.mjs <spec.json> [out.docx]
//
// spec.json の形式は examples/sample-report.json を参照。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

let docx;
try {
  docx = await import('docx');
} catch {
  console.error('`docx` パッケージが見つかりません。先に `npm install`（このスキルのディレクトリで）を実行してください。');
  console.error('導入できない環境では、同じ内容を Markdown で出力して代替してください。');
  process.exit(2);
}
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  Table, TableRow, TableCell, WidthType, AlignmentType, BorderStyle,
} = docx;

const specPath = process.argv[2];
if (!specPath) {
  console.error('Usage: node scripts/generate-report.mjs <spec.json> [out.docx]');
  process.exit(1);
}
const spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));

const today = spec.date || new Date().toISOString().slice(0, 10);
const outPath = process.argv[3]
  || path.join(SKILL_DIR, 'out', `本番反映依頼書_${today}.docx`);
fs.mkdirSync(path.dirname(outPath), { recursive: true });

// ---- 部品 ----
function h1(text) { return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 240, after: 120 } }); }
function h2(text) { return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 100 } }); }
function p(text, opts = {}) { return new Paragraph({ children: [new TextRun({ text: text ?? '', ...opts })], spacing: { after: 80 } }); }
function label(k, v) {
  return new Paragraph({
    spacing: { after: 40 },
    children: [new TextRun({ text: `${k}: `, bold: true }), new TextRun({ text: String(v ?? '—') })],
  });
}

const IMPACT_COLOR = { '影響あり': 'C00000', '要エンジニア確認': 'B45F06', '影響なし': '38761D' };

function cell(text, { bold = false, header = false, color } = {}) {
  return new TableCell({
    shading: header ? { fill: 'F2F2F2' } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({ children: [new TextRun({ text: String(text ?? '—'), bold: bold || header, color })] })],
  });
}
function table(headers, rows) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' },
      left: { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' },
      right: { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 4, color: 'DDDDDD' },
      insideVertical: { style: BorderStyle.SINGLE, size: 4, color: 'DDDDDD' },
    },
    rows: [
      new TableRow({ tableHeader: true, children: headers.map((h) => cell(h, { header: true })) }),
      ...rows.map((r) => new TableRow({ children: r })),
    ],
  });
}

// ---- 本文 ----
const children = [];

children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 120 },
  children: [new TextRun({ text: spec.title || '本番反映依頼書', bold: true, size: 32 })],
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 200 },
  children: [new TextRun({ text: '（Salesforce Sandbox改修 → 本番反映 依頼）', color: '666666' })],
}));

children.push(label('依頼者', spec.requestedBy));
children.push(label('作成日', today));
children.push(label('確認元Sandbox', spec.sandboxAlias));
children.push(label('対象オブジェクト', spec.targetObject));

children.push(h1('1. やりたいこと（要約）'));
children.push(p(spec.summary));

children.push(h1('2. 変更内容（Before / After）'));
if (Array.isArray(spec.changes) && spec.changes.length) {
  children.push(table(
    ['種別', 'メタデータ名', '対象項目', '変更前 (Before)', '変更後 (After)'],
    spec.changes.map((c) => [
      cell(c.component), cell(c.name), cell(c.field), cell(c.before), cell(c.after),
    ]),
  ));
} else {
  children.push(p('（変更項目の記載がありません）', { italics: true }));
}

children.push(h1('3. 入力規則（VR）との整合性'));
children.push(p('変更対象の項目に関連する入力規則を確認しました。'));
if (Array.isArray(spec.validationRules) && spec.validationRules.length) {
  children.push(table(
    ['入力規則名', '関連項目', '影響判定', '内容 / 対応'],
    spec.validationRules.map((v) => [
      cell(v.name), cell(v.relatedField),
      cell(v.impact, { bold: true, color: IMPACT_COLOR[v.impact] }),
      cell(v.note),
    ]),
  ));
  children.push(p(`確認したVR: ${spec.validationRules.length}件`, { italics: true, color: '666666' }));
} else {
  children.push(p('（関連VRの記載がありません。要確認）', { italics: true, color: 'B45F06' }));
}

children.push(h1('4. エンジニアへの依頼事項'));
children.push(p(spec.engineerRequest));
children.push(p('※ この変更に LWC / Apex などのコード実装は含まれません（非エンジニア環境の制約により）。', { italics: true, color: '666666' }));

if (spec.notes) {
  children.push(h2('補足'));
  children.push(p(spec.notes));
}

const doc = new Document({ sections: [{ children }] });
const buffer = await Packer.toBuffer(doc);
fs.writeFileSync(outPath, buffer);
console.log(`✅ 依頼書を生成しました: ${outPath}`);
