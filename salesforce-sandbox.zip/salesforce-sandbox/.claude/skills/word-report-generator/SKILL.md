---
name: word-report-generator
description: "非エンジニアが承認したSandboxのUI改修内容を、エンジニアへの『本番反映依頼書』としてWord(.docx)に整理するスキル。監査ログではなく、非エンジニアが言葉にしづらい部分をClaudeが代わりに言語化して伝えるのが目的。Use this skill when the non-engineer says things like『エンジニアに本番反映を頼みたい』『この変更を依頼書にして』『Word/ドキュメントにまとめて』, or after a Sandbox change has been approved and needs to be handed off to an engineer for production deployment. 含める内容: やりたいことの要約 / Before-After / 確認したVR(入力規則)との整合性 / エンジニアへの依頼事項."
allowed-tools: Bash Read Write
metadata:
  version: "1.0"
  author: local
  runtime: node (docx npm package)
---

## いつ使うか

対象Sandboxで試した改修が**非エンジニアに承認された後**、それを本番へ反映するのは
エンジニアです。このスキルは、非エンジニアがうまく言語化できない技術的意図・前提・注意点を
Claude が代わりに整理し、**エンジニアがそのまま作業に入れる依頼書(.docx)** を作ります。

> これは監査ログではありません（監査は `logs/operations.jsonl`）。依頼書は「何を・なぜ・どう反映
> してほしいか、そして入力規則(VR)と矛盾しないこと」を人間が読んで理解するための文書です。

## 手順

### 1. 会話から依頼書の材料を集める

以下を、この環境での実際の変更内容・VR確認結果に基づいて埋めます（推測で埋めない。
不明点は「要エンジニア確認」と明記する）。

- **やりたいことの要約**: 非エンジニアの目的を業務言葉で。なぜこの変更が必要かを1〜3文で。
- **Before / After**: 変更したメタデータ（FlexiPage / カスタム項目 / リストビュー / 入力規則）ごとに、
  変更前と変更後を対で。可能なら API 名も添える。
- **確認したVRとの整合性**: CLAUDE.md の運用フロー4で抽出した、変更対象項目に関連する入力規則を
  一覧し、各VRについて「影響なし / 影響あり(→対応) / 要エンジニア確認」を記す。
- **エンジニアへの依頼事項**: 本番反映で気をつける点、順序、確認してほしいこと、依頼者・希望時期。

### 2. 依頼書スペック(JSON)を書き出す

[examples/sample-report.json](examples/sample-report.json) の形式に合わせて、スペックJSONを
（例）`out/report-spec.json` に Write します。

### 3. Word(.docx)を生成する

```
# docx はプロジェクト直下の `npm install`（ルート package.json）に集約済み。
# 未導入なら一度だけ: (プロジェクト直下で) npm install
node .claude/skills/word-report-generator/scripts/generate-report.mjs <spec.json> [出力先.docx]
```

出力パス未指定なら（スキル配下の）`out/本番反映依頼書_<日付>.docx` に生成します。
生成後、保存先を非エンジニアに自然言語で伝えてください（「この .docx をエンジニアに渡してください」）。

### 補足

- 想定ランタイムは **Claude Desktop の Code タブ（Node v20+ のみ / python不要）**。既定は node 製 `docx`。
- 環境に docx 公式スキル(`/mnt/skills/public/docx`)があればそれでも構いません。
- `docx` 未導入で `npm install` もできない環境では、同じ内容を Markdown で出力して代替してください。
