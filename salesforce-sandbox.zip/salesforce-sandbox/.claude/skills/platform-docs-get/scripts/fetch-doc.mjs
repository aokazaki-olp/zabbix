#!/usr/bin/env node
// fetch-doc.mjs — Node-only の公式ドキュメント素取得ヘルパ（Node v20+ の global fetch を使用）。
// python/playwright は使いません。
//
// 使い方: node scripts/fetch-doc.mjs <official-salesforce-doc-url>
//
// 注意:
//  - これは「naive fetch」です。静的寄りの developer.salesforce.com 等では本文が取れますが、
//    JSレンダリングされる help.salesforce.com や JS-heavy ページでは shell(空/ローディング)しか
//    取れないことがあります。その場合は組み込みの WebFetch ツールで取得してください（SKILL.md参照）。
//  - 公式Salesforceドメイン以外は拒否します（第三者ブログ等で裏取りしないため）。

const OFFICIAL = /(^|\.)(salesforce\.com|lightningdesignsystem\.com)$/i;

const url = process.argv[2];
if (!url) {
  console.error('Usage: node scripts/fetch-doc.mjs <official-salesforce-doc-url>');
  process.exit(1);
}
let u;
try { u = new URL(url); } catch { console.error(`不正なURL: ${url}`); process.exit(1); }
if (!/^https?:$/.test(u.protocol) || !OFFICIAL.test(u.hostname)) {
  console.error(`公式Salesforceドメインのみ許可します（指定: ${u.hostname}）。`);
  process.exit(2);
}

function htmlToText(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<\/(p|div|li|h[1-6]|section|article|tr)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&quot;/g, '"')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

const SHELL_MARKERS = ['Loading', 'Sorry to interrupt', 'CSS Error', "couldn't find that page"];

try {
  const res = await fetch(u.href, {
    redirect: 'follow',
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; sf-docs-get/1.0)', 'Accept': 'text/html' },
    signal: AbortSignal.timeout(30000),
  });
  const html = await res.text();
  const text = htmlToText(html);
  const looksShell = text.length < 400 || SHELL_MARKERS.some((m) => text.includes(m) && text.length < 1200);

  console.log(`URL: ${u.href}`);
  console.log(`HTTP: ${res.status}`);
  console.log(`chars(text): ${text.length}`);
  if (looksShell) {
    console.log('WARN: shell/JSレンダリングの可能性。本文抽出に失敗しているかもしれません → WebFetchツールで再取得してください。');
  }
  console.log('----- TEXT (先頭6000字) -----');
  console.log(text.slice(0, 6000));
  process.exit(0);
} catch (e) {
  console.error(`取得失敗: ${e.message} → WebFetchツールで取得してください。`);
  process.exit(3);
}
