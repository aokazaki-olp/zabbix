#!/usr/bin/env node
// setup.mjs — プレースホルダを実値に一括置換する（人手の転記ミス防止）。
//
// 使い方:
//   node .claude/setup.mjs --alias <SANDBOX_ALIAS> --object <TARGET_OBJECT_API>
// 例:
//   node .claude/setup.mjs --alias uatsb --object Order__c
//
// 置換後の認証は、この環境の外（人間が端末）で1回だけ:
//   sf org login web --alias <SANDBOX_ALIAS> --instance-url https://test.salesforce.com
// ※ フックは agent 経由の org login を禁止しています。認証は必ず手動で。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function arg(name) {
  const i = process.argv.indexOf(name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : null;
}
const alias = arg('--alias');
const object = arg('--object');

if (!alias || !object) {
  console.error('Usage: node .claude/setup.mjs --alias <SANDBOX_ALIAS> --object <TARGET_OBJECT_API>');
  process.exit(1);
}
if (!/^[A-Za-z0-9_]+$/.test(alias)) { console.error(`不正なalias: ${alias}`); process.exit(1); }
if (!/^[A-Za-z0-9_]+$/.test(object)) { console.error(`不正なobject API名: ${object}`); process.exit(1); }

// 置換対象ファイル（存在するものだけ処理）。
const files = [
  '.claude/settings.json',
  '.claude/allowed-org.json',
  'CLAUDE.md',
  'AGENTS.md',
  'SETUP.md',
  'SKILLS_PIN.md',
  '.claude/skills/word-report-generator/SKILL.md',
];

let changed = 0;
for (const rel of files) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) continue;
  const before = fs.readFileSync(p, 'utf8');
  const after = before
    .replaceAll('__SANDBOX_ALIAS__', alias)
    .replaceAll('__TARGET_OBJECT__', object);
  if (after !== before) { fs.writeFileSync(p, after); changed++; console.log(`  patched: ${rel}`); }
}

console.log(`\n✅ ${changed} ファイルを更新しました（alias=${alias}, object=${object}）。`);
console.log('\n次のステップ（この環境の外・端末で人間が1回だけ実施）:');
console.log(`  sf org login web --alias ${alias} --instance-url https://test.salesforce.com`);
console.log('\n認証後の最初のSalesforce操作で、フックが OrganizationId を自動記録してロックします。');
console.log('検証: node .claude/hooks/selftest.mjs');
