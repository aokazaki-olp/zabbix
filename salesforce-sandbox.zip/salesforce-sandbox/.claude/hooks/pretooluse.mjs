#!/usr/bin/env node
// PreToolUse フック（実行前の強制検証）。
// 対象: Bash(sf/sfdx/curl等) と Salesforce MCP 呼び出しの両方。
//   → Bash経由でsf CLIやcurlを直接叩く抜け道も必ず捕捉する。
//
// 判定: 純粋関数 evaluate() の結果に従い、block=true なら exit 2 で機械的にブロックする
//       （exit 2 の stderr が Claude に返り、ツール実行は行われない）。
// ブロックした試行は PostToolUse が発火しないため、ここで operations.jsonl に記録する。

import { readStdin, parseHookInput, loadAllowed, evaluate, appendLog } from './hook-lib.mjs';

function summarizeInput(toolName, toolInput) {
  if (toolName === 'Bash') return { command: toolInput?.command };
  return toolInput; // MCP引数はそのまま（org指定の追跡に必要）
}

const raw = await readStdin();
const input = parseHookInput(raw);
const toolName = input.tool_name || '';
const toolInput = input.tool_input || {};
const allowed = loadAllowed();

const result = evaluate(toolName, toolInput, allowed);

if (!result.inScope) {
  // 対象外ツールは素通り（ログもしない）。
  process.exit(0);
}

const logBase = {
  event: 'PreToolUse',
  tool: toolName,
  args: summarizeInput(toolName, toolInput),
  in_scope: true,
  allowed_alias: allowed.alias,
  locked: allowed.locked,
  verified_org_id: result.info?.orgId ?? null,
  verified_is_sandbox: result.info?.isSandbox ?? null,
};

if (result.block) {
  appendLog({ ...logBase, decision: 'BLOCK', reason: result.reason });
  process.stderr.write(`⛔ ブロックしました: ${result.reason}\n`);
  process.exit(2); // ← ツール実行を機械的に阻止
}

appendLog({ ...logBase, decision: 'ALLOW', reason: result.reason });
process.exit(0);
