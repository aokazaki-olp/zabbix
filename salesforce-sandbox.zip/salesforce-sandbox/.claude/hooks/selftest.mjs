#!/usr/bin/env node
// selftest.mjs — live orgが無くても hook の統制が機械的に働くことを検証する。
//   1) 純粋関数(evaluateBash/evaluateMcp/verifyOrgIdentity)の判定
//   2) 実際の pretooluse.mjs / posttooluse.mjs を stdin→exit-code で end-to-end 実行
//   3) ブロック試行が operations.jsonl に記録されること
//   4) 初回接続の自動ロック
//
// 使い方: node .claude/hooks/selftest.mjs

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import {
  evaluateBash, evaluateMcp, verifyOrgIdentity, loadAllowed,
} from './hook-lib.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PRE = path.join(__dirname, 'pretooluse.mjs');
const POST = path.join(__dirname, 'posttooluse.mjs');

const SANDBOX_ID = '00DSB0000000001AAA';
const OTHER_ID = '00DPRD0000000009AAA';
const SB_HOST = 'mysb.sandbox.my.salesforce.com';

const sandboxInfo = JSON.stringify({ status: 0, result: { id: SANDBOX_ID, isSandbox: true, instanceUrl: `https://${SB_HOST}` } });
const otherSandboxInfo = JSON.stringify({ status: 0, result: { id: OTHER_ID, isSandbox: true, instanceUrl: 'https://other.sandbox.my.salesforce.com' } });
const productionInfo = JSON.stringify({ status: 0, result: { id: SANDBOX_ID, isSandbox: false, instanceUrl: 'https://prod.my.salesforce.com' } });

let pass = 0, fail = 0;
const fails = [];
function check(name, cond) {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else { fail++; fails.push(name); console.log(`  ❌ ${name}`); }
}

// ---- 一時プロジェクトを用意（本物の allowed-org.json / logs を汚さない）----
function makeTempProject(allowedObj) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sfhook-'));
  fs.mkdirSync(path.join(dir, '.claude'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'logs'), { recursive: true });
  fs.writeFileSync(path.join(dir, '.claude', 'allowed-org.json'), JSON.stringify(allowedObj, null, 2));
  return dir;
}

function runHook(script, hookInput, { projectDir, orgInfo }) {
  const env = { ...process.env, CLAUDE_PROJECT_DIR: projectDir };
  if (orgInfo !== undefined) env.SFHOOK_TEST_ORGINFO = orgInfo;
  else delete env.SFHOOK_TEST_ORGINFO;
  const r = spawnSync('node', [script], { input: JSON.stringify(hookInput), env, encoding: 'utf8' });
  return { status: r.status, stderr: r.stderr || '', stdout: r.stdout || '' };
}

const LOCKED = { alias: 'uatsb', orgId: SANDBOX_ID, isSandbox: true, instanceHost: SB_HOST, locked: true };
const UNLOCKED = { alias: 'uatsb', orgId: null, isSandbox: null, instanceHost: null, locked: false };
const UNCONFIGURED = { alias: '__SANDBOX_ALIAS__', orgId: null, isSandbox: null, instanceHost: null, locked: false };

const bash = (command) => ({ tool_name: 'Bash', tool_input: { command } });
const mcp = (tool, input) => ({ tool_name: tool, tool_input: input || {} });

console.log('\n=== 1. 純粋関数の判定 ===');
check('locked: 別orgId接続はブロック', verifyOrgIdentity({ orgId: OTHER_ID, isSandbox: true }, LOCKED).block === true);
check('locked: 同orgId+Sandboxは許可', verifyOrgIdentity({ orgId: SANDBOX_ID, isSandbox: true }, LOCKED).block === false);
check('locked: 本番(IsSandbox=false)はブロック', verifyOrgIdentity({ orgId: SANDBOX_ID, isSandbox: false }, LOCKED).block === true);
check('locked: 情報取得不能はfail-closedでブロック', verifyOrgIdentity(null, LOCKED).block === true);
check('bash: --target-org 別org指定はブロック', evaluateBash('sf project deploy start --target-org prod', LOCKED, () => sandboxInfo).block === true);
check('bash: -o 別org指定はブロック', evaluateBash('sf data query -o otherorg -q "SELECT Id FROM Account"', LOCKED, () => sandboxInfo).block === true);
check('bash: 許可alias明示は許可', evaluateBash('sf data query --target-org uatsb -q "SELECT Id FROM Account"', LOCKED, () => sandboxInfo).block === false);
check('bash: org login はブロック', evaluateBash('sf org login web --alias neworg', LOCKED, () => sandboxInfo).block === true);
check('bash: config set target-org はブロック', evaluateBash('sf config set target-org prod', LOCKED, () => sandboxInfo).block === true);
check('bash: 許可instance以外へのcurlはブロック', evaluateBash('curl https://login.salesforce.com/services/oauth2/token', LOCKED, () => sandboxInfo).block === true);
check('bash: Salesforce無関係コマンドは対象外', evaluateBash('ls -la && echo hello', LOCKED, () => sandboxInfo).inScope === false);
check('bash: 未設定aliasはブロック', evaluateBash('sf data query -q "SELECT Id FROM Account"', UNCONFIGURED, () => sandboxInfo).block === true);
check('mcp: 別alias指定はブロック', evaluateMcp('mcp__Salesforce DX__run_soql_query', { usernameOrAlias: 'prod' }, LOCKED, () => sandboxInfo).block === true);
check('mcp: 指定なし+一致Sandboxは許可', evaluateMcp('mcp__Salesforce DX__run_soql_query', {}, LOCKED, () => sandboxInfo).block === false);
check('mcp: 接続先が別orgId(MCP誤設定時)はブロック', evaluateMcp('mcp__Salesforce DX__deploy_metadata', {}, LOCKED, () => otherSandboxInfo).block === true);

console.log('\n=== 2. end-to-end: PreToolUse の exit code (2=ブロック) ===');
{
  const proj = makeTempProject(LOCKED);
  check('E2E bash: 別org接続 → exit 2', runHook(PRE, bash('sf data query -q "SELECT Id FROM Account"'), { projectDir: proj, orgInfo: otherSandboxInfo }).status === 2);
  check('E2E bash: 許可Sandbox接続 → exit 0', runHook(PRE, bash('sf data query -q "SELECT Id FROM Account"'), { projectDir: proj, orgInfo: sandboxInfo }).status === 0);
  check('E2E bash: 本番接続 → exit 2', runHook(PRE, bash('sf data query -q "SELECT Id FROM Account"'), { projectDir: proj, orgInfo: productionInfo }).status === 2);
  check('E2E bash: --target-org prod → exit 2', runHook(PRE, bash('sf project deploy start -o prod'), { projectDir: proj, orgInfo: sandboxInfo }).status === 2);
  check('E2E bash: org login → exit 2', runHook(PRE, bash('sf org login web'), { projectDir: proj, orgInfo: sandboxInfo }).status === 2);
  check('E2E bash: curl to login.salesforce.com → exit 2', runHook(PRE, bash('curl -s https://login.salesforce.com/x'), { projectDir: proj, orgInfo: sandboxInfo }).status === 2);
  check('E2E mcp: 別alias指定 → exit 2', runHook(PRE, mcp('mcp__Salesforce DX__run_soql_query', { usernameOrAlias: 'prod' }), { projectDir: proj, orgInfo: sandboxInfo }).status === 2);
  check('E2E mcp: 一致Sandbox → exit 0', runHook(PRE, mcp('mcp__Salesforce DX__run_soql_query', {}), { projectDir: proj, orgInfo: sandboxInfo }).status === 0);
  check('E2E mcp: MCP接続先が別org → exit 2', runHook(PRE, mcp('mcp__Salesforce DX__deploy_metadata', {}), { projectDir: proj, orgInfo: otherSandboxInfo }).status === 2);
  check('E2E: 対象外ツール(Read) → exit 0', runHook(PRE, { tool_name: 'Read', tool_input: { file_path: '/etc/hosts' } }, { projectDir: proj, orgInfo: sandboxInfo }).status === 0);

  console.log('\n=== 3. ブロック試行が operations.jsonl に記録される ===');
  const logPath = path.join(proj, 'logs', 'operations.jsonl');
  const lines = fs.existsSync(logPath) ? fs.readFileSync(logPath, 'utf8').trim().split('\n').filter(Boolean).map((l) => JSON.parse(l)) : [];
  const blocks = lines.filter((l) => l.decision === 'BLOCK');
  check('BLOCK ログが1件以上記録されている', blocks.length >= 1);
  check('別org接続のBLOCKログが記録されている', blocks.some((l) => /不一致|本番|非Sandbox/.test(l.reason || '')));
  check('org loginのBLOCKログが記録されている', blocks.some((l) => /認証/.test(l.reason || '')));
  check('curlのBLOCKログが記録されている', blocks.some((l) => /HTTP/.test(l.reason || '')));
  check('対象外ツールはログされない', !lines.some((l) => l.tool === 'Read'));
  fs.rmSync(proj, { recursive: true, force: true });
}

console.log('\n=== 4. 初回接続の自動ロック(PostToolUse) ===');
{
  const proj = makeTempProject(UNLOCKED);
  const before = JSON.parse(fs.readFileSync(path.join(proj, '.claude', 'allowed-org.json'), 'utf8'));
  check('ロック前: locked=false', before.locked === false);
  runHook(POST, { tool_name: 'Bash', tool_input: { command: 'sf data query -q "SELECT Id FROM Account"' }, tool_response: { success: true } }, { projectDir: proj, orgInfo: sandboxInfo });
  const after = loadAllowed(path.join(proj, '.claude', 'allowed-org.json'));
  check('ロック後: locked=true', after.locked === true);
  check('ロック後: orgId が固定された', after.orgId === SANDBOX_ID);
  check('ロック後: isSandbox=true', after.isSandbox === true);
  fs.rmSync(proj, { recursive: true, force: true });
}

console.log(`\n=== RESULT: ${pass} passed / ${fail} failed ===`);
if (fail > 0) { console.log('FAILED:', fails.join(' | ')); process.exit(1); }
process.exit(0);
