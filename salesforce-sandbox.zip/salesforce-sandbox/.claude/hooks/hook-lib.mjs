// hook-lib.mjs
// 対象Sandbox(alias)以外のいかなるSalesforce組織にも接続させないための
// 機械的検証ロジック（純粋関数中心・テスト可能）と、機械的ログ追記。
//
// 設計の要点:
//  - 検証ロジックは副作用の無い純粋関数(evaluateBash / evaluateMcp / verifyOrgIdentity)。
//    → selftest.mjs から直接呼べる = live orgが無くても機械的に動作確認できる。
//  - org情報の取得(getOrgInfo)だけが外部(sf CLI)へ依存。runnerを差し替え可能にして
//    テスト時はフェイクを注入する。
//  - fail-closed: 情報が取れない/ロック済みで不一致 → 必ずブロック。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execSync } from 'node:child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// このファイルは <project>/.claude/hooks/hook-lib.mjs に置かれる前提。
export const PROJECT_DIR =
  process.env.CLAUDE_PROJECT_DIR || path.resolve(__dirname, '..', '..');

export const ALLOWED_ORG_PATH = path.join(PROJECT_DIR, '.claude', 'allowed-org.json');
export const LOG_PATH = path.join(PROJECT_DIR, 'logs', 'operations.jsonl');

// aliasが未設定であることを示すセンチネル（SETUP.md参照）。
export const ALIAS_SENTINEL = '__SANDBOX_ALIAS__';

// ---------------------------------------------------------------------------
// allowed-org.json の読み書き
// ---------------------------------------------------------------------------
export function loadAllowed(p = ALLOWED_ORG_PATH) {
  try {
    const raw = fs.readFileSync(p, 'utf8');
    const j = JSON.parse(raw);
    return {
      alias: j.alias ?? ALIAS_SENTINEL,
      orgId: j.orgId ?? null,
      isSandbox: j.isSandbox ?? null,
      instanceHost: j.instanceHost ?? null,
      locked: j.locked === true,
    };
  } catch {
    return { alias: ALIAS_SENTINEL, orgId: null, isSandbox: null, instanceHost: null, locked: false };
  }
}

export function saveAllowed(obj, p = ALLOWED_ORG_PATH) {
  const body = {
    alias: obj.alias ?? ALIAS_SENTINEL,
    orgId: obj.orgId ?? null,
    isSandbox: obj.isSandbox ?? null,
    instanceHost: obj.instanceHost ?? null,
    locked: obj.locked === true,
    lockedAt: obj.lockedAt ?? null,
    note: obj.note ?? '初回の有効なSandbox接続時に自動でロックされます。手で編集しないでください。',
  };
  fs.writeFileSync(p, JSON.stringify(body, null, 2) + '\n');
  return body;
}

export function isConfigured(allowed) {
  return !!allowed.alias && allowed.alias !== ALIAS_SENTINEL;
}

// ---------------------------------------------------------------------------
// Bashコマンド文字列の解析
// ---------------------------------------------------------------------------

// Salesforce関連コマンドかどうか。
export function isSalesforceCommand(cmd) {
  if (!cmd || typeof cmd !== 'string') return false;
  // sf / sfdx の起動
  if (/(^|[\s;&|(`])(sf|sfdx)([\s]|$)/.test(cmd)) return true;
  // @salesforce/cli, @salesforce/mcp を npx 等で起動
  if (/@salesforce\/(cli|mcp)/.test(cmd)) return true;
  if (/\bsfdx-cli\b/.test(cmd)) return true;
  // Salesforceドメインへの HTTP アクセス（curl/wget 等）
  if (/\b(curl|wget|http|https-request|Invoke-WebRequest|iwr)\b/i.test(cmd) &&
      extractSalesforceHosts(cmd).length > 0) return true;
  return false;
}

const TARGET_FLAGS = new Set([
  '--target-org', '-o',
  '--targetusername', '-u',
  '--target-dev-hub', '-v',
  '--targetdevhubusername',
]);

// --target-org 等で指定された org 値をすべて抽出する。
export function extractTargetOrgValues(cmd) {
  const values = [];
  if (!cmd) return values;
  // フラグ=値 形式
  const eqRe = /(?:--target-org|--targetusername|--target-dev-hub|--targetdevhubusername|-o|-u|-v)=("[^"]*"|'[^']*'|\S+)/g;
  let m;
  while ((m = eqRe.exec(cmd)) !== null) values.push(unquote(m[1]));
  // フラグ␣値 形式（簡易トークナイズ）
  const tokens = cmd.match(/"[^"]*"|'[^']*'|\S+/g) || [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (TARGET_FLAGS.has(t) && i + 1 < tokens.length) {
      const v = unquote(tokens[i + 1]);
      if (v && !v.startsWith('-')) values.push(v);
    }
  }
  return values;
}

function unquote(s) {
  if (!s) return s;
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    return s.slice(1, -1);
  }
  return s;
}

// コマンド内のSalesforceドメインホストを抽出する。
export function extractSalesforceHosts(cmd) {
  const hosts = [];
  if (!cmd) return hosts;
  const urlRe = /https?:\/\/([^\/\s"'`]+)/gi;
  let m;
  while ((m = urlRe.exec(cmd)) !== null) {
    const host = m[1].toLowerCase();
    if (/(\.|^)(salesforce\.com|force\.com|forceusercontent\.com|force\.mil|sfdc\.sh|cloudforce\.com|salesforce\.mil)$/.test(host) ||
        /\.my\.salesforce\.com$/.test(host) || /\.lightning\.force\.com$/.test(host)) {
      hosts.push(host);
    }
  }
  return hosts;
}

// org を認証/作成/切替/ログアウトしようとするコマンドか（この環境では全面禁止）。
export function isOrgMutatingAuthCommand(cmd) {
  if (!cmd) return false;
  return (
    /\bsf(dx)?\s+org\s+(login|create|logout|delete)\b/.test(cmd) ||
    /\bsf(dx)?\s+org:(login|create|logout|delete)\b/.test(cmd) ||
    /\borg\s+login\s+(web|device|jwt|access-token|sfdx-url)\b/.test(cmd) ||
    /\bforce:auth:/.test(cmd) ||
    /\bauth:(web|jwt|device|sfdxurl):/.test(cmd) ||
    /\bsf(dx)?\s+config\s+set\s+target-org\b/.test(cmd) ||          // 既定orgの付け替え
    /\bsf(dx)?\s+alias\s+(set|unset)\b/.test(cmd)                    // aliasの付け替え
  );
}

// ---------------------------------------------------------------------------
// org情報の取得（唯一の外部依存。runnerを差し替え可能）
// ---------------------------------------------------------------------------

// sf は Salesforce CLI（node製）。Node-only 環境では `npm i -g @salesforce/cli`、
// もしくはプロジェクトへローカル導入(node_modules/.bin/sf)で使えます。
// 解決順: SFHOOK_SF_BIN → PATH の `sf` → プロジェクトの node_modules/.bin/sf。
function sfCandidates() {
  const list = [];
  if (process.env.SFHOOK_SF_BIN) list.push(process.env.SFHOOK_SF_BIN);
  list.push('sf');
  const localBin = path.join(PROJECT_DIR, 'node_modules', '.bin', 'sf');
  const localCmd = localBin + (process.platform === 'win32' ? '.cmd' : '');
  list.push(process.platform === 'win32' ? shellQuote(localCmd) : shellQuote(localBin));
  return list;
}

// テスト/ブリッジ用のフック:
//  - SFHOOK_TEST_ORGINFO が設定されていれば、その JSON をそのまま sf の出力とみなす。
//  - SFHOOK_SF_BIN で sf の起動コマンドを差し替え可能（例: WSLで "cmd.exe /c sf"）。
export function defaultRunner(alias) {
  const testFixture = process.env.SFHOOK_TEST_ORGINFO;
  if (testFixture) return testFixture;
  for (const bin of sfCandidates()) {
    try {
      const out = execSync(`${bin} org display --target-org ${shellQuote(alias)} --json`, {
        stdio: ['ignore', 'pipe', 'ignore'],
        timeout: 30000,
        encoding: 'utf8',
      });
      if (out && out.trim()) return out;
    } catch {
      // 次の候補へ
    }
  }
  return null; // sf が見つからない/失敗 → 情報取得不能（ロック済みなら fail-closed）
}

function shellQuote(s) {
  return `'${String(s).replace(/'/g, `'\\''`)}'`;
}

// sf org display --json の出力から orgId / isSandbox / instanceHost を取り出す。
export function getOrgInfo(alias, runner = defaultRunner) {
  try {
    const out = runner(alias);
    if (!out) return null;
    const j = typeof out === 'string' ? JSON.parse(out) : out;
    const r = j.result || j;
    const orgId = r.id || r.orgId || r.Id || r.organizationId || null;
    let isSandbox = r.isSandbox;
    if (isSandbox === undefined) isSandbox = r.IsSandbox;
    const instanceUrl = r.instanceUrl || r.instance_url || null;
    let instanceHost = null;
    if (instanceUrl) {
      try { instanceHost = new URL(instanceUrl).host.toLowerCase(); } catch { /* noop */ }
    }
    if (!orgId) return null;
    return {
      orgId,
      isSandbox: isSandbox === true || isSandbox === 'true',
      instanceHost,
    };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// org同一性の検証（純粋関数）
// ---------------------------------------------------------------------------
export function verifyOrgIdentity(info, allowed) {
  if (!info) {
    if (allowed.locked) {
      return { block: true, reason: 'org情報を取得できず検証不能。fail-closedでブロックしました。' };
    }
    // 未ロック（scaffold/初回接続前）かつ情報取得不可 → 実接続していないので保留。
    return { block: false, reason: 'org未ロック・情報取得不可（未接続/scaffold状態）。', verified: false };
  }
  if (info.isSandbox !== true) {
    return { block: true, reason: `接続先が本番または非Sandbox (IsSandbox=${info.isSandbox}) です。ブロックしました。`, info };
  }
  if (allowed.locked) {
    if (String(info.orgId) !== String(allowed.orgId)) {
      return {
        block: true,
        reason: `OrganizationIdが許可値と不一致です（実際=${info.orgId} / 許可=${allowed.orgId}）。ブロックしました。`,
        info,
      };
    }
    return { block: false, reason: '許可Sandbox（OrganizationId一致・IsSandbox=true）を確認しました。', verified: true, info };
  }
  // 未ロック + 有効なSandbox → 許可し、PostToolUseでロックする候補にする。
  return {
    block: false,
    reason: '初回接続: 有効なSandboxを確認。この接続をロック対象にします。',
    verified: true,
    lockCandidate: info,
    info,
  };
}

// ---------------------------------------------------------------------------
// Bash / MCP 呼び出しの総合評価
// ---------------------------------------------------------------------------
export function evaluateBash(cmd, allowed, runner = defaultRunner) {
  if (!isSalesforceCommand(cmd)) return { inScope: false, block: false };

  if (!isConfigured(allowed)) {
    return { inScope: true, block: true, reason: `SETUP未完了: 許可Sandbox aliasが未設定(${ALIAS_SENTINEL})です。SETUP.mdの手順を実行してください。` };
  }

  // 1) org認証/作成/切替/付け替え系は全面禁止（他orgを絶対に認証しない統制）。
  if (isOrgMutatingAuthCommand(cmd)) {
    return { inScope: true, block: true, reason: 'org認証/作成/切替/logout/alias付け替えはこの環境では禁止です。認証はSETUP手順（人間が端末で1回だけ）でのみ実施してください。' };
  }

  // 2) --target-org 等で許可alias以外を指定していないか。
  const targets = extractTargetOrgValues(cmd);
  for (const t of targets) {
    if (t !== allowed.alias) {
      return { inScope: true, block: true, reason: `他org指定を検出（指定=${t} / 許可=${allowed.alias}）。ブロックしました。` };
    }
  }

  // 3) Salesforceドメインへの直接HTTP(curl/wget等)は、許可instance以外をブロック。
  const hosts = extractSalesforceHosts(cmd);
  for (const h of hosts) {
    if (!allowed.instanceHost || h !== allowed.instanceHost) {
      return { inScope: true, block: true, reason: `Salesforceドメインへの直接HTTPアクセス(${h})を検出。許可instance(${allowed.instanceHost || '未ロック'})以外はブロックします。` };
    }
  }

  // 4) 実接続先のorg同一性を検証。
  const info = getOrgInfo(allowed.alias, runner);
  return { inScope: true, ...verifyOrgIdentity(info, allowed) };
}

// MCPツール(Salesforce DX)呼び出しの評価。
export function evaluateMcp(toolName, toolInput, allowed, runner = defaultRunner) {
  // Salesforce MCP以外は対象外（この環境ではSalesforce DXのみ設定）。
  if (!/^mcp__/.test(toolName || '')) return { inScope: false, block: false };

  if (!isConfigured(allowed)) {
    return { inScope: true, block: true, reason: `SETUP未完了: 許可Sandbox aliasが未設定(${ALIAS_SENTINEL})です。SETUP.mdの手順を実行してください。` };
  }

  const t = toolInput && typeof toolInput === 'object' ? toolInput : {};
  const target = t.usernameOrAlias || t.targetOrg || t.username || t.org || t.alias || null;
  if (target && target !== allowed.alias) {
    return { inScope: true, block: true, reason: `MCP呼び出しのorg指定(${target})が許可alias(${allowed.alias})と不一致。ブロックしました。` };
  }

  const info = getOrgInfo(allowed.alias, runner);
  return { inScope: true, ...verifyOrgIdentity(info, allowed) };
}

// ---------------------------------------------------------------------------
// 機械的ログ追記（Claudeの判断を介さない）
// ---------------------------------------------------------------------------
export function appendLog(entry) {
  try {
    fs.mkdirSync(path.dirname(LOG_PATH), { recursive: true });
    fs.appendFileSync(LOG_PATH, JSON.stringify({ timestamp: new Date().toISOString(), ...entry }) + '\n');
  } catch (e) {
    // ログ失敗は握りつぶさず stderr に出す（ただしフックの判定は妨げない）。
    process.stderr.write(`[hook-lib] log append failed: ${e.message}\n`);
  }
}

// stdin(JSON)を最後まで読む。
export function readStdin() {
  return new Promise((resolve) => {
    let data = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (c) => (data += c));
    process.stdin.on('end', () => resolve(data));
    // stdinが無い環境でもハングしないように保険。
    setTimeout(() => resolve(data), 2000).unref?.();
  });
}

export function parseHookInput(raw) {
  try { return JSON.parse(raw || '{}'); } catch { return {}; }
}

// tool_name と tool_input から評価対象を判定して評価する共通処理。
export function evaluate(toolName, toolInput, allowed, runner = defaultRunner) {
  if (toolName === 'Bash') {
    const cmd = toolInput && toolInput.command ? String(toolInput.command) : '';
    return evaluateBash(cmd, allowed, runner);
  }
  if (/^mcp__/.test(toolName || '')) {
    return evaluateMcp(toolName, toolInput, allowed, runner);
  }
  return { inScope: false, block: false };
}
