#!/usr/bin/env node
// PostToolUse フック（機械的なログ記録＋初回ロック）。
// 対象: Bash(sf/sfdx/curl等) と Salesforce MCP 呼び出しの両方。
//
// 役割:
//  1) 実行結果を operations.jsonl に1行追記する（Claudeの判断を介さない）。
//  2) allowlistが未ロックで、実接続が有効なSandboxだった場合、その OrganizationId を
//     自動的に記録してロックする（以降はこの値以外を機械ブロック）。

import {
  readStdin, parseHookInput, loadAllowed, saveAllowed,
  evaluate, appendLog, getOrgInfo,
} from './hook-lib.mjs';

function summarizeInput(toolName, toolInput) {
  if (toolName === 'Bash') return { command: toolInput?.command };
  return toolInput;
}

function isSuccess(toolResponse) {
  if (toolResponse == null) return null;
  if (typeof toolResponse === 'object') {
    if (toolResponse.success === false || toolResponse.error || toolResponse.isError) return false;
    if (toolResponse.success === true) return true;
  }
  return true; // 応答があり明示的な失敗フラグが無ければ成功とみなす
}

const raw = await readStdin();
const input = parseHookInput(raw);
const toolName = input.tool_name || '';
const toolInput = input.tool_input || {};
const toolResponse = input.tool_response;
const allowed = loadAllowed();

const result = evaluate(toolName, toolInput, allowed);
if (!result.inScope) process.exit(0);

const success = isSuccess(toolResponse);

// 初回ロック: 未ロック + 実行成功 + 実接続が有効Sandbox → orgIdを固定してロック。
let locked = allowed.locked;
let lockedOrgId = allowed.orgId;
if (!allowed.locked && success !== false) {
  const info = result.info || getOrgInfo(allowed.alias);
  if (info && info.isSandbox === true && info.orgId) {
    const saved = saveAllowed({
      alias: allowed.alias,
      orgId: info.orgId,
      isSandbox: true,
      instanceHost: info.instanceHost,
      locked: true,
      lockedAt: new Date().toISOString(),
    });
    locked = true;
    lockedOrgId = saved.orgId;
    appendLog({
      event: 'PostToolUse',
      tool: toolName,
      action: 'AUTO_LOCK',
      allowed_alias: allowed.alias,
      locked_org_id: saved.orgId,
      verified_is_sandbox: true,
      reason: '初回の有効なSandbox接続を検出し、OrganizationIdを固定・ロックしました。',
    });
  }
}

appendLog({
  event: 'PostToolUse',
  tool: toolName,
  args: summarizeInput(toolName, toolInput),
  in_scope: true,
  result: success === false ? 'FAILURE' : 'SUCCESS',
  allowed_alias: allowed.alias,
  locked,
  verified_org_id: result.info?.orgId ?? lockedOrgId ?? null,
  verified_is_sandbox: result.info?.isSandbox ?? null,
});

process.exit(0);
