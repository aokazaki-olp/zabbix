# AGENTS.md — 運用ルール

このプロジェクトの方針は @CLAUDE.md に集約されています。まずそちらを読んでください。
本ファイルは、運用者（環境を用意する人・レビューする人）向けの補足です。

## この環境は何か

非エンジニアが Claude Desktop の「Code」タブから、自然言語だけで対象Sandboxの
オブジェクトUI（FlexiPage・項目・リストビュー・入力規則）を安全に試行錯誤するための箱です。
「安全」は指示ではなく**仕組み**で担保します（@CLAUDE.md の制約1）。

## 機械的統制のしくみ（4層）

1. **MCPの接続先を1組織に固定**: [.claude/settings.json](.claude/settings.json) の
   `--orgs __SANDBOX_ALIAS__`。`orgs` ツールセットは無効（他orgの存在を見せない）。
   有効ツールセットは `metadata`（deploy/retrieve）と `data`（run_soql_query）のみ。
2. **PreToolUse フックによる実行前ブロック**: [.claude/hooks/pretooluse.mjs](.claude/hooks/pretooluse.mjs)。
   - matcher は `Bash|mcp__.*` = **Bash経由のsf/curlも、MCP呼び出しも両方**捕捉。
   - 接続先の OrganizationId が [.claude/allowed-org.json](.claude/allowed-org.json) の許可値と一致し、
     かつ IsSandbox=true でなければ **exit 2 でブロック**。
   - `--target-org`/`-o` 等での他org指定、`sf org login` 等の認証系、許可instance以外へのcurlもブロック。
3. **許可orgIdの自動ロック**: 初回の有効なSandbox接続時に [posttooluse.mjs](.claude/hooks/posttooluse.mjs) が
   OrganizationId を記録して `locked:true` にする。以降その値以外は機械ブロック。人手での転記ミスが無い。
4. **機械的ログ**: 全操作（ALLOW/BLOCK/結果）を [logs/operations.jsonl](logs/operations.jsonl) に追記。

## 統制の自己検証

```
node .claude/hooks/selftest.mjs
```

live org が無くても、他org/本番/認証/curl/MCP誤設定の各ケースが**機械的にブロックされること**と、
ブロック試行がログに残ることを検証します（34ケース）。

## やってはいけないこと（運用者向け）

- `__SANDBOX_ALIAS__` 以外の org をこのマシン/プロジェクトで `sf org login` しない。
- `allowed-org.json` の `orgId`/`locked` を手で書き換えない（ロックは自動）。
- 除外スキル（`dx-org-switch`, `integration-connectivity-connected-app-configure`）を追加しない。
- LWC/Apex実装を伴う依頼は、この環境では扱わずエンジニアへ回す。

## セットアップ

[SETUP.md](SETUP.md) を参照。プレースホルダ `__SANDBOX_ALIAS__` / `__TARGET_OBJECT__` の置換と、
対象Sandboxの認証（人間が1回だけ）を行います。
