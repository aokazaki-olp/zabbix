# SETUP.md — セットアップ手順（管理者/運用者が実施）

非エンジニアが使い始める前に、**技術が分かる人が一度だけ**行う作業です。

この環境は **Node.js v20+（v24推奨）のみ**で動くように作ってあります（python不要）。
想定ランタイムは **Claude Desktop の「Code」タブ**です。

## 前提

- Node.js v20+（このマシンで確認済み: v24 系）。python は不要。
- 依存の導入（初回1回、プロジェクト直下で）:
  ```
  npm install                 # docx（Word生成）等を取得
  npm i -g @salesforce/cli    # sf（node製CLI・認証に使用。Node-only）
  ```
  - `sf` はグローバル導入を推奨。ローカルに置きたい場合は `npm i @salesforce/cli` を追加すれば、
    フックが `node_modules/.bin/sf` を自動解決します。
  - MCP サーバ（`@salesforce/mcp`）は `npx -y` が自動取得するため事前導入は不要。

## 手順

### 1. プレースホルダを実値に置換

```
node .claude/setup.mjs --alias <SANDBOX_ALIAS> --object <対象オブジェクトAPI名>
```

例: `node .claude/setup.mjs --alias uatsb --object Order__c`

`__SANDBOX_ALIAS__` と `__TARGET_OBJECT__` が各ファイルに反映されます。

### 2. 対象Sandboxを認証（人間が端末で1回だけ）

> ⚠️ agent（Claude）経由の `sf org login` はフックが禁止しています。必ず手動で行ってください。
> このマシンには **対象Sandbox以外の org を絶対に認証しない**でください（統制の前提）。

```
sf org login web --alias <SANDBOX_ALIAS> --instance-url https://test.salesforce.com
```

Sandbox のログイン URL は `https://test.salesforce.com` です（本番の `login.salesforce.com` ではない）。

### 3. 許可orgIdの自動ロックを確認

認証後、Claude Code をこのプロジェクトで開き、最初の Salesforce 操作
（例: 「対象オブジェクトの入力規則を一覧して」）を実行します。
PostToolUse フックが接続先の `OrganizationId` と `IsSandbox=true` を確認し、
[.claude/allowed-org.json](.claude/allowed-org.json) に記録して `locked:true` にします。

確認:
```
cat .claude/allowed-org.json    # orgId が入り locked:true になっていればOK
```

### 4. 統制の自己検証（live org 不要）

```
node .claude/hooks/selftest.mjs
```

他org/本番/認証コマンド/curl/MCP誤設定が**機械的にブロック**され、ブロック試行がログに残ることを
34ケースで検証します。全て pass することを確認してください。

---

## 認証ストアの一貫性（重要）

MCP（`npx @salesforce/mcp`）もフックの org 検証（`sf org display`）も、**同じ node が見る認証ストア
（`$HOME/.sfdx` / `$HOME/.sf`）**を参照します。したがって、**Claude Desktop の Code タブが動く同じ環境で
`sf org login` を実行**してください（そこに認証を作れば MCP もフックも一貫して同じSandboxを見ます）。

> 参考: WSL 側の node と Windows 側の node は認証ストアが別です。運用する node 環境で認証を作ること。
> 特殊事情で sf の起動方法を差し替えたい場合のみ、環境変数 `SFHOOK_SF_BIN` を使えます
> （[hook-lib.mjs](.claude/hooks/hook-lib.mjs) 参照）。

## `platform-docs-get`（Node-only 版）

公式ドキュメントの裏取りに使います。**python は不要**です（元スキルの playwright 抽出スクリプトは撤去済み）。
取得は次の順で行います:
1. 組み込みの **WebFetch ツール**（JS-heavy な developer/help ページ向け・最優先）
2. `node .claude/skills/platform-docs-get/scripts/fetch-doc.mjs <公式URL>`（静的寄りページの素取得）

## Word 依頼書生成（`word-report-generator`）

node 製の `docx` パッケージで `.docx` を生成します。依存は**ルートの `npm install`** に集約済み
（スキル配下に個別の node_modules は不要）。生成は:
```
node .claude/skills/word-report-generator/scripts/generate-report.mjs <spec.json> [out.docx]
```

## 除外スキルの確認

```
ls .claude/skills            # dx-org-switch / connected-app 系が無いこと
```

## スキルの再取得（ピン留め）

スキルは commit `4bc39ed386445987b3031675c960eb7f3f9cc3d9` に固定しています。再取得は
[scripts/fetch-skills.sh](scripts/fetch-skills.sh) を実行（除外スキルは取得しません）。詳細は
[SKILLS_PIN.md](SKILLS_PIN.md)。
