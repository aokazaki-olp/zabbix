# CLAUDE.md — 非エンジニア向け Salesforce Sandbox UI改修環境

このプロジェクトは、**非エンジニアが自然言語だけで、特定のSandbox内オブジェクトのUI
（ページレイアウト＝FlexiPage、項目、リストビュー等）をトライアンドエラーで改修する**ための
環境です。想定ランタイムは **Claude Desktop の「Code」タブ（Node v20+ のみ・python不要）**。
あなた（Claude）は、以下の方針を厳守してください。

## 0. 相手は非エンジニアです

- 相手は Salesforce の内部知識も、Lightning App Builder / Metadata API / sf CL/ MCP といった
  ツールの存在も**知らない前提**で対応してください。
- 説明・確認・提案はすべて**自然言語**で行い、専門用語には必ず短い言い換えを添えてください。
- 「どのボタンを押す」ではなく「何を実現したいか」を聞き出し、こちらで方法に翻訳します。

## 1. 絶対制約（最優先・最重要）

1. **この環境は対象Sandbox（alias: `__SANDBOX_ALIAS__`）以外のいかなるSalesforce組織
   （本番・他Sandbox）にも接続してはなりません。**
2. これは「指示を守る」ことではなく、**技術的な仕組みで機械的に**保証されています:
   - MCPサーバは `--orgs __SANDBOX_ALIAS__` のみ許可（[.claude/settings.json](.claude/settings.json)）。
   - PreToolUse フックが、Bash（`sf`/`sfdx`/`curl` 等）と MCP 呼び出しの**両方**を実行前に検証し、
     接続先の OrganizationId / IsSandbox が許可値と一致しなければ **exit 2 で強制ブロック**します
     （[.claude/hooks/](.claude/hooks/)、許可値は [.claude/allowed-org.json](.claude/allowed-org.json)）。
   - あなたがこの制約を回避するコマンドを書く必要はありません。書いてもフックが機械的に止めます。
3. **LWC / Apex の実装が必要な変更は行わないでください。** 相手の要望がコード実装を伴う場合は、
   作業を止めて「これはエンジニアへの相談が必要な内容です」と自然言語で案内してください。
   （例: 画面に独自ロジックのボタン、トリガ、カスタムコンポーネント等）
4. org を**認証・作成・切替・logout** するコマンド（`sf org login/create/logout`, `config set target-org`,
   `alias set` 等）は禁止です。フックがブロックします。認証は人間が SETUP 手順で1回だけ行います。

## 2. あなたが使えるスキル（[.claude/skills/](.claude/skills/)）

公式 `forcedotcom/sf-skills`（commit `4bc39ed`）から取得した以下のみが入っています:

| スキル | 用途 |
|---|---|
| `platform-docs-get` | 公式ドキュメント取得（**常時**。機能説明・仕様確認は必ずこれで裏取り。Node-only版=WebFetchツール＋`fetch-doc.mjs`、python不要） |
| `platform-flexipage-generate` | Lightningページ（FlexiPage）の作成・編集 |
| `platform-custom-field-generate` | カスタム項目の作成・編集 |
| `platform-list-view-generate` | リストビューの作成・編集 |
| `platform-validation-rule-generate` | 入力規則（Validation Rule）の作成・編集 |
| `platform-permission-set-generate` | 権限セットの作成・編集 |
| `word-report-generator`（自作） | エンジニアへの本番反映依頼書（Word）を生成 |

> 旧スキル名（`generating-flexipage` 等）は上流でリネーム済みです。`switching-org`（→`dx-org-switch`）と
> `configuring-connected-apps`（→`integration-connectivity-connected-app-configure`）は統制方針と衝突するため
> **意図的に除外**しています。追加取得もしないでください。

**機能や仕様を説明するときは、必ず `platform-docs-get` で公式ドキュメントを確認してから回答**してください
（第三者ブログや記憶だけで断定しない）。

## 3. 運用フロー（毎回これに従う）

1. 非エンジニアが自然言語で「こうしたい」を伝える。
2. あなたは `platform-docs-get` で最新の公式仕様を確認しつつ、実現方法を**自然言語で**提案する。
   コード実装（LWC/Apex）が必要と分かった時点で作業を止め、エンジニア相談を案内する（制約1-3）。
3. Sandbox 内でメタデータを変更して試す（フックが常に接続先を検証）。
4. **デプロイ前に必ず、変更対象の項目・オブジェクトに関連する既存の入力規則（Validation Rule）を
   全件抽出し、影響の有無を相手に提示する**（次節）。
5. 相手が内容を確認して**承認した場合のみ**デプロイを実行する。承認前にデプロイしない。
6. 相手が「エンジニアに本番反映を頼みたい」と言ったら、`word-report-generator` スキルで
   依頼書（Word）を生成する。

## 4. 入力規則（VR）影響確認は必須

対象オブジェクト `__TARGET_OBJECT__` には Validation Rule が **80種類以上**存在します。
**項目やレイアウトを変更する前に必ず**、その変更が触れる項目名を含む VR を全件洗い出し、
「この変更で影響し得る入力規則はこれです／無いと考えられます」と根拠付きで提示してください。

- 既存VRの取得は MCP の `run_soql_query`（ToolingAPI の `ValidationRule`）または
  `platform-validation-rule-generate` スキルの手順に従う。
- 変更する項目の API 名が、各VRの `errorConditionFormula` / 対象項目に含まれるかを突き合わせる。
- 「影響あり」の VR は、変更後に矛盾（常に成立/常に失敗、エラーメッセージの不整合）が起きないかを
  自然言語で説明し、相手の承認を得る。
- 判断がつかない VR は「要エンジニア確認」として明示する（勝手に無効化・削除しない）。

## 5. 変更対象と保存場所

- FlexiPage: [force-app/main/default/flexipages/](force-app/main/default/flexipages/)
- カスタム項目・VR・リストビュー: [force-app/main/default/objects/](force-app/main/default/objects/)

## 6. ログ

すべての Salesforce 操作（成功・失敗・ブロック）は [logs/operations.jsonl](logs/operations.jsonl) に
フックが機械的に追記します。あなたがここへ書き込む必要はありません。

## 7. セットアップ状態の確認

`__SANDBOX_ALIAS__` / `__TARGET_OBJECT__` がこのまま残っている場合、環境は**まだセットアップ未完了**です。
その状態では作業を始めず、[SETUP.md](SETUP.md) の手順（管理者が実施）を案内してください。

運用ルールの説明は [AGENTS.md](AGENTS.md) にもあります。
