# SKILLS_PIN.md — スキルのピン留め情報

`.claude/skills/` 配下の公式スキルは、以下のコミットに**固定**しています
（`forcedotcom/sf-skills` は頻繁に更新されるため）。

- Repo: `https://github.com/forcedotcom/sf-skills`
- Pinned commit: `4bc39ed386445987b3031675c960eb7f3f9cc3d9`（`main`, 取得日 2026-08-06）

## 取得したスキル（6つ）と旧名対応

上流でリポジトリ名（旧 afv-library）とスキル名がリネームされています。指示書の旧名 → 現行名:

| 指示書の旧名 | 現行名（配置したもの） |
|---|---|
| generating-flexipage | `platform-flexipage-generate` |
| generating-custom-field | `platform-custom-field-generate` |
| generating-list-view | `platform-list-view-generate` |
| generating-validation-rule | `platform-validation-rule-generate` |
| generating-permission-set | `platform-permission-set-generate` |
| fetching-salesforce-docs | `platform-docs-get` |

## 意図的に除外（配置しない）

| 指示書の旧名 | 現行名 | 理由 |
|---|---|---|
| switching-org | `dx-org-switch` | org切替。単一org統制と衝突 |
| configuring-connected-apps | `integration-connectivity-connected-app-configure` | Connected App設定変更。統制と衝突 |

その他（Data Cloud/Data360、OmniStudio、Experience/UI Bundle、Agentforce、Apex/LWC実装系 等）も
今回の用途に無関係なため配置していません。

## Node-only 化に伴う改変（当環境固有）

- `platform-docs-get`: 上流の **python/playwright 抽出スクリプトを撤去**し、Node-only の
  `scripts/fetch-doc.mjs`（Node の fetch のみ）＋ 組み込み WebFetch ツールでの取得に置換。
  プレイブック本文は pin(4bc39ed) のまま。frontmatter の `cliTools` は `python3` → `node>=20` に変更。
  → 再取得スクリプト `scripts/fetch-skills.sh` は原本を取得するため、Node-only 化の再適用は手動 or
    `fetch-doc.mjs` を再配置し python スクリプトを削除すること。

## 自作スキル

- `word-report-generator` … エンジニアへの本番反映依頼書（Word）を生成（node製 `docx`。依存はルート
  `package.json` に集約）。

## 再取得

```
bash scripts/fetch-skills.sh
```

上記コミットから6スキルのみをコピーし、除外2スキルは取得しません。
